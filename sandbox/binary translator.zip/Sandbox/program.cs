using System;


class program
{
    static void Main(string[] args)
    {
        MainMenu mm = new MainMenu();
        mm.Startup();
    }
}
    